def test_ejercicio_02():
    import ejercicio_02
